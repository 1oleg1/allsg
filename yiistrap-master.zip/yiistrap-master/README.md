Yiistrap
========

[![Latest Stable Version](https://poser.pugx.org/crisu83/yiistrap/v/stable.png)](https://packagist.org/packages/crisu83/yiistrap)
[![Build Status](https://travis-ci.org/crisu83/yiistrap.png)](https://travis-ci.org/crisu83/yiistrap)

Twitter Bootstrap for Yii.

Documentation can be found here:
[http://www.getyiistrap.com](http://www.getyiistrap.com)

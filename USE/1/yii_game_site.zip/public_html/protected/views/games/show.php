<?php //страница с подробной информацией о выбранной игре ?>
<?php $this->renderPartial('_full_desc', array('game'=>$model)); ?>
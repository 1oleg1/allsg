<h2>Жанры</h2>
<ul>
<?php
foreach ($types as $type) {
	//каждый пункт списка - ссылка на страницу с играми данного жанра
	//жанр указывается с помощью параметра в get запросе - type_id
	echo '<li>'.CHtml::link($type->t_name, array('games/list', 'type_id'=>$type->t_id)).'</li>';
}
?>
</ul>
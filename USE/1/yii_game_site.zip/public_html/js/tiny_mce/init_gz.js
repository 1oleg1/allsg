tinyMCE_GZ.init({
    themes : 'simple',
    disk_cache : true,
    languages:"ru",
    debug : false
});
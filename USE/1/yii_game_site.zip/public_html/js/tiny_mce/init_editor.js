tinyMCE.init({
    mode:"textareas",
    theme:"simple",
    language:"ru"
});
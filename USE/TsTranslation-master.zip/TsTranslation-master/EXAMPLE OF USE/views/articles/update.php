<?php
	/************************************/
	
	/**
     * Menu or breadcrumbs or other code
     */
	 
	/************************************/
?>
<h1>Update Articles <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form', array('model' => $model)); ?>